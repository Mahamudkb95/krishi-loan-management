document.addEventListener('DOMContentLoaded', () => {
    // Tab switching logic
    const navLinks = document.querySelectorAll('.nav-link');
    const contentPanels = document.querySelectorAll('.dashboard-content');
    const helpButtons = document.querySelectorAll('.help-header-btn');
    const shopNowButtons = document.querySelectorAll('.shop-now-header-btn');
    const backToDashboardButton = document.getElementById('back-to-dashboard-btn');
    const backToDashboardFromSettingsBtn = document.getElementById('back-to-dashboard-btn-from-settings');
    const backToDashboardFromDetailsBtn = document.getElementById('back-to-dashboard-from-details');
    const backToDashboardFromEditBtn = document.getElementById('back-to-dashboard-from-edit');
    const backToDashboardFromLoanDetailsBtn = document.getElementById('back-to-dashboard-from-loan-details');
    const backToDashboardFromMachineUploadBtn = document.getElementById('back-to-dashboard-from-machine-upload');
    const backToDashboardFromComplaintBtn = document.getElementById('back-to-dashboard-from-complaint');
    const profileSettingsLink = document.getElementById('profile-settings-link');

    let lastActiveDashboardId = 'farmer-dashboard'; // Keep track of the last active tab

    const showPanel = (panelId: string) => {
        contentPanels.forEach(panel => {
            if (panel.id === panelId) {
                panel.classList.add('active');
            } else {
                panel.classList.remove('active');
            }
        });
        window.scrollTo(0, 0); // Scroll to top on page change
    };

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            const targetId = (link as HTMLElement).dataset.tab;
            if (!targetId) return;

            // Update active link
            navLinks.forEach(navLink => navLink.classList.remove('active'));
            link.classList.add('active');
            
            showPanel(targetId);
            lastActiveDashboardId = targetId; // Update the last active dashboard

            if (targetId === 'team-leader-dashboard') {
                renderTeamLeaderDashboard();
            } else if (targetId === 'project-manager-dashboard') {
                renderProjectManagerDashboard();
            }
        });
    });

    // Help Button Logic
    helpButtons.forEach(button => {
        button.addEventListener('click', () => {
            showPanel('help-page');
        });
    });

    // Back to Dashboard Button Logic
    const backToDashboard = () => showPanel(lastActiveDashboardId);
    if (backToDashboardButton) backToDashboardButton.addEventListener('click', backToDashboard);
    if (backToDashboardFromSettingsBtn) backToDashboardFromSettingsBtn.addEventListener('click', backToDashboard);
    if (backToDashboardFromDetailsBtn) backToDashboardFromDetailsBtn.addEventListener('click', backToDashboard);
    if (backToDashboardFromEditBtn) backToDashboardFromEditBtn.addEventListener('click', backToDashboard);
    if (backToDashboardFromLoanDetailsBtn) backToDashboardFromLoanDetailsBtn.addEventListener('click', backToDashboard);
    if (backToDashboardFromMachineUploadBtn) backToDashboardFromMachineUploadBtn.addEventListener('click', backToDashboard);
    if (backToDashboardFromComplaintBtn) backToDashboardFromComplaintBtn.addEventListener('click', backToDashboard);

    
    // Shop Now Button Logic
    shopNowButtons.forEach(button => {
        button.addEventListener('click', () => {
            const shopNowCard = document.querySelector('#farmer-dashboard .shop-now');
            if (shopNowCard) {
                shopNowCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        });
    });

    // --- Farmer Dashboard Logic ---

    // DOM Elements
    const withdrawForm = document.getElementById('withdraw-form') as HTMLFormElement;
    const withdrawAmountInput = document.getElementById('withdraw-amount') as HTMLInputElement;
    const balanceAmountElement = document.getElementById('balance-amount');
    const transactionList = document.getElementById('transaction-list');
    const profileIcon = document.getElementById('profile-icon');
    const profileDropdown = document.getElementById('profile-dropdown');
    
    // Page Navigation Buttons
    const toggleDetailsBtn = document.getElementById('toggle-details-btn');
    const detailedTransactionTableBody = document.querySelector('#detailed-transaction-table tbody');
    const editInfoBtn = document.getElementById('edit-info-btn');
    const loanDetailsBtn = document.getElementById('loan-details-btn');

    // Verification Card Elements
    const machineVerificationCard = document.querySelector('.machine-verification') as HTMLElement;
    const verificationPendingDiv = document.getElementById('machine-verification-pending');
    const verificationNotReceivedDiv = document.getElementById('machine-verification-not-received');
    const machineReceivedYesBtn = document.getElementById('machine-received-yes');
    const machineReceivedNoBtn = document.getElementById('machine-received-no');
    const reapplyMachineBtn = document.getElementById('reapply-machine-btn') as HTMLButtonElement;
    
    // Edit Info Page Elements
    const cancelEditPageBtn = document.getElementById('cancel-edit-page-btn');
    const editInfoForm = document.getElementById('edit-info-form') as HTMLFormElement;
    const nidUploadInput = document.getElementById('nid-upload') as HTMLInputElement;
    const fileNameDisplay = document.getElementById('file-name-display');
    const verifyNidBtn = document.getElementById('verify-nid-btn');
    const verifyPhoneBtn = document.getElementById('verify-phone-btn');
    const farmerInfoContent = document.getElementById('farmer-info-content');
    const profilePicUploadInput = document.getElementById('profile-pic-upload') as HTMLInputElement;
    const profilePicPreview = document.getElementById('edit-profile-pic-preview') as HTMLImageElement;

    // Profile Settings Page Elements
    const changePasswordForm = document.getElementById('change-password-form') as HTMLFormElement;
    const contactInfoForm = document.getElementById('contact-info-form') as HTMLFormElement;
    const notificationPrefsForm = document.getElementById('notification-prefs-form') as HTMLFormElement;
    const toggle2faBtn = document.getElementById('toggle-2fa-btn');
    const status2fa = document.getElementById('2fa-status');
    
    // Loan Details Page Elements
    const loanSummaryContent = document.getElementById('loan-summary-content');
    const loanTransactionTableBody = document.querySelector('#loan-transaction-table tbody');

    // Machine Upload Page Elements
    const machineUploadForm = document.getElementById('machine-upload-form') as HTMLFormElement;
    const memoUploadInput = document.getElementById('memo-upload') as HTMLInputElement;
    const machineUploadInput = document.getElementById('machine-upload') as HTMLInputElement;
    const memoPreview = document.getElementById('memo-preview') as HTMLImageElement;
    const machinePreview = document.getElementById('machine-preview') as HTMLImageElement;

    // Complaint Page Elements
    const complaintContactInfo = document.getElementById('complaint-contact-info');
    const makeComplaintBtn = document.getElementById('make-complaint-btn');

    // Withdraw Modal Elements
    const modalOverlay = document.getElementById('withdraw-modal-overlay');
    const modalCloseBtn = document.getElementById('modal-close-btn');
    const modalStep1 = document.getElementById('modal-step-1');
    const modalStep2 = document.getElementById('modal-step-2');
    const modalStep3 = document.getElementById('modal-step-3');
    const modalAccountLabel = document.getElementById('modal-account-label');
    const modalAccountNumberInput = document.getElementById('modal-account-number') as HTMLInputElement;
    const modalContinueBtn = document.getElementById('modal-continue-btn');
    const modalConfirmAmount = document.getElementById('modal-confirm-amount');
    const modalConfirmMethod = document.getElementById('modal-confirm-method');
    const modalConfirmNumber = document.getElementById('modal-confirm-number');
    const modalCancelBtn = document.getElementById('modal-cancel-btn');
    const modalConfirmBtn = document.getElementById('modal-confirm-btn');
    const modalSuccessOkBtn = document.getElementById('modal-success-ok-btn');

    // All Offers Modal Elements
    const viewAllOffersBtn = document.getElementById('view-all-offers-btn');
    const allOffersModalOverlay = document.getElementById('all-offers-modal-overlay');
    const allOffersModalCloseBtn = document.getElementById('all-offers-modal-close-btn');

    // --- Farmer Inbox Elements ---
    const farmerInboxBtn = document.getElementById('farmer-inbox-btn');
    const backToFarmerDashboardFromInboxBtn = document.getElementById('back-to-farmer-dashboard-from-inbox');
    const backToFarmerInboxFromDetailBtn = document.getElementById('back-to-farmer-inbox-from-detail');
    const farmerInboxReplyForm = document.getElementById('farmer-inbox-reply-form') as HTMLFormElement;

    // --- Team Leader Dashboard Elements ---
    const editTlInfoBtn = document.getElementById('edit-tl-info-btn');
    const backToTlDashboardFromEditBtn = document.getElementById('back-to-tl-dashboard-from-edit');
    const backToTlDashboardFromDetailsBtn = document.getElementById('back-to-tl-dashboard-from-details');
    const cancelTlEditPageBtn = document.getElementById('cancel-tl-edit-page-btn');
    const editTlInfoForm = document.getElementById('edit-tl-info-form') as HTMLFormElement;
    const tlProfilePicUploadInput = document.getElementById('tl-profile-pic-upload') as HTMLInputElement;
    const tlProfilePicPreview = document.getElementById('edit-tl-profile-pic-preview') as HTMLImageElement;
    const tlInboxBtn = document.getElementById('tl-inbox-btn');
    const backToTlDashboardFromInboxBtn = document.getElementById('back-to-tl-dashboard-from-inbox');
    const backToTlInboxFromDetailBtn = document.getElementById('back-to-tl-inbox-from-detail');
    const tlInboxReplyForm = document.getElementById('tl-inbox-reply-form') as HTMLFormElement;

    // --- Project Manager Dashboard Elements ---
    const backToPmDashboardFromTlDetailsBtn = document.getElementById('back-to-pm-dashboard-from-tl-details');
    const backToTlDetailsFromFarmerViewBtn = document.getElementById('back-to-tl-details-from-farmer-view');
    const pmInboxBtn = document.getElementById('pm-inbox-btn');
    const backToPmDashboardFromInboxBtn = document.getElementById('back-to-pm-dashboard-from-inbox');
    const backToInboxFromDetailBtn = document.getElementById('back-to-inbox-from-detail');
    const pmInboxReplyForm = document.getElementById('pm-inbox-reply-form') as HTMLFormElement;

    // Data structures
    interface Transaction {
        type: string;
        date: string;
        amount: number;
        status: 'Completed' | 'Pending';
    }

    interface LoanTransaction {
        date: string;
        description: string;
        amount: number;
        balance: number;
    }
    
    type VerificationStatus = 'Verified' | 'Not Verified' | 'Pending';
    type MachineStatus = 'Pending' | 'Delivered' | 'Not Received';

    interface FarmerData {
        name: string;
        id: string;
        profilePic: string;
        phone: string;
        address: string;
        land: string;
        teamLeaderId: string;
        teamLeader: string;
        teamLeaderPhone: string;
        projectManager: string;
        projectManagerPhone: string;
        nidStatus: VerificationStatus;
        phoneStatus: VerificationStatus;
        nidNumber: string;
        machineStatus: MachineStatus;
        transactions: Transaction[];
        loanTransactions: LoanTransaction[];
        hasLoan: boolean;
    }

    interface TeamLeaderData {
        name: string;
        id: string;
        profilePic: string;
        phone: string;
        projectManager: string;
    }

    interface ComplaintMessage {
        id: string;
        farmerId: string;
        farmerName: string;
        teamLeaderId: string;
        subject: string;
        message: string;
        timestamp: Date;
        readStatus: {
            farmer: boolean;
            teamLeader: boolean;
            projectManager: boolean;
        };
        replies: {
            from: 'Project Manager' | 'Team Leader' | 'Farmer';
            message: string;
            timestamp: Date;
        }[];
    }
    
    const DEFAULT_PROFILE_PIC = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23757575'%3E%3Cpath d='M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z'/%3E%3C/svg%3E";

    // Initial state
    let loggedInFarmer: FarmerData = {
        name: 'মোঃ আব্দুল করিম',
        id: 'K-78652',
        teamLeaderId: 'TL-101',
        profilePic: DEFAULT_PROFILE_PIC,
        phone: '01712345678',
        address: 'গ্রাম: বগুরা, উপজেলা: সদর, জেলা: বগুড়া',
        land: '৫ একর',
        teamLeader: 'আরিফুল ইসলাম',
        teamLeaderPhone: '01812345678',
        projectManager: 'নাসরিন আক্তার',
        projectManagerPhone: '01912345678',
        nidStatus: 'Verified',
        phoneStatus: 'Verified',
        nidNumber: '19901234567890',
        machineStatus: 'Pending',
        hasLoan: true,
        transactions: [
            { type: 'শস্য বিক্রয় (ফেরত)', date: '১০ জুলাই, ২০২৪', amount: 15000, status: 'Pending' },
            { type: 'সরকারী ভর্তুকি', date: '৫ জুলাই, ২০২৪', amount: 10000, status: 'Completed' },
            { type: 'সার ক্রয়', date: '১ জুলাই, ২০২৪', amount: -3000, status: 'Completed' },
            { type: 'বীজ ক্রয়', date: '২৮ জুন, ২০২৪', amount: -5000, status: 'Completed' },
            { type: 'যন্ত্রপাতির জন্য ব্যয়', date: '২৫ জুন, ২০২৪', amount: -20000, status: 'Completed' },
            { type: 'মোট লোন প্রাপ্তি', date: '২০ জুন, ২০২৪', amount: 50000, status: 'Completed' },
        ],
        loanTransactions: [
            { date: '২০ জুন, ২০২৪', description: 'লোন বিতরণ', amount: 50000, balance: 50000 },
            { date: '২০ জুলাই, ২০২৪', description: 'কিস্তি পরিশোধ', amount: -5000, balance: 45000 },
            { date: '২০ আগস্ট, ২০২৪', description: 'কিস্তি পরিশোধ', amount: -5000, balance: 40000 },
        ],
    };

    let allFarmers: FarmerData[] = [
        loggedInFarmer,
        {
            name: 'রহিমা বেগম',
            id: 'K-78653',
            teamLeaderId: 'TL-101',
            profilePic: DEFAULT_PROFILE_PIC,
            phone: '01700000001',
            address: 'গ্রাম: শেরপুর, উপজেলা: সদর, জেলা: বগুড়া',
            land: '৩ একর',
            teamLeader: 'আরিফুল ইসলাম',
            teamLeaderPhone: '01812345678',
            projectManager: 'নাসরিন আক্তার',
            projectManagerPhone: '01912345678',
            nidStatus: 'Verified',
            phoneStatus: 'Verified',
            nidNumber: '19851234567891',
            machineStatus: 'Delivered',
            hasLoan: true,
            transactions: [ { type: 'মোট লোন প্রাপ্তি', date: '২২ জুন, ২০২৪', amount: 40000, status: 'Completed' } ],
            loanTransactions: [ { date: '২২ জুন, ২০২৪', description: 'লোন বিতরণ', amount: 40000, balance: 40000 } ],
        },
        {
            name: 'সোলায়মান খান',
            id: 'K-78654',
            teamLeaderId: 'TL-101',
            profilePic: DEFAULT_PROFILE_PIC,
            phone: '01700000002',
            address: 'গ্রাম: কাহালু, উপজেলা: কাহালু, জেলা: বগুড়া',
            land: '৮ একর',
            teamLeader: 'আরিফুল ইসলাম',
            teamLeaderPhone: '01812345678',
            projectManager: 'নাসরিন আক্তার',
            projectManagerPhone: '01912345678',
            nidStatus: 'Verified',
            phoneStatus: 'Verified',
            nidNumber: '19951234567892',
            machineStatus: 'Not Received',
            hasLoan: false,
            transactions: [],
            loanTransactions: [],
        },
        {
            name: 'ফাতেমা আক্তার',
            id: 'K-78655',
            teamLeaderId: 'TL-102',
            profilePic: DEFAULT_PROFILE_PIC,
            phone: '01700000003',
            address: 'গ্রাম: দুপচাঁচিয়া, উপজেলা: দুপচাঁচিয়া, জেলা: বগুড়া',
            land: '৪ একর',
            teamLeader: 'কামরুল হাসান',
            teamLeaderPhone: '01800000002',
            projectManager: 'নাসরিন আক্তার',
            projectManagerPhone: '01912345678',
            nidStatus: 'Verified',
            phoneStatus: 'Verified',
            nidNumber: '19921234567893',
            machineStatus: 'Delivered',
            hasLoan: true,
            transactions: [ { type: 'মোট লোন প্রাপ্তি', date: '২৩ জুন, ২০২৪', amount: 60000, status: 'Completed' } ],
            loanTransactions: [ { date: '২৩ জুন, ২০২৪', description: 'লোন বিতরণ', amount: 60000, balance: 60000 } ],
        },
        {
            name: 'জামাল উদ্দিন',
            id: 'K-78656',
            teamLeaderId: 'TL-102',
            profilePic: DEFAULT_PROFILE_PIC,
            phone: '01700000004',
            address: 'গ্রাম: শিবগঞ্জ, উপজেলা: শিবগঞ্জ, জেলা: বগুড়া',
            land: '৬ একর',
            teamLeader: 'কামরুল হাসান',
            teamLeaderPhone: '01800000002',
            projectManager: 'নাসরিন আক্তার',
            projectManagerPhone: '01912345678',
            nidStatus: 'Verified',
            phoneStatus: 'Verified',
            nidNumber: '19881234567894',
            machineStatus: 'Not Received',
            hasLoan: true,
            transactions: [ { type: 'মোট লোন প্রাপ্তি', date: '২৪ জুন, ২০২৪', amount: 75000, status: 'Completed' } ],
            loanTransactions: [ { date: '২৪ জুন, ২০২৪', description: 'লোন বিতরণ', amount: 75000, balance: 75000 } ],
        }
    ];

    let teamLeaders: TeamLeaderData[] = [
        {
            name: 'আরিফুল ইসলাম',
            id: 'TL-101',
            profilePic: DEFAULT_PROFILE_PIC,
            phone: '01812345678',
            projectManager: 'নাসরিন আক্তার',
        },
        {
            name: 'কামরুল হাসান',
            id: 'TL-102',
            profilePic: DEFAULT_PROFILE_PIC,
            phone: '01800000002',
            projectManager: 'নাসরিন আক্তার',
        }
    ];
    
    let complaintMessages: ComplaintMessage[] = [];
    let currentViewingMessageId: string | null = null;


    let teamLeaderData: TeamLeaderData = teamLeaders[0]; // For TL dashboard view
    let currentTlIdForPm: string | null = null;

    let currentBalance = 0;
    let withdrawalRequest: { amount: number; method: string; number?: string } | null = null;


    // Helper Functions
    const formatCurrency = (amount: number): string => {
        return `৳${Math.abs(amount).toLocaleString('bn-BD')}`;
    };

    const formatDate = (date: Date): string => {
        return new Intl.DateTimeFormat('bn-BD', {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        }).format(date);
    };

    const formatDateTime = (date: Date): string => {
        return new Intl.DateTimeFormat('bn-BD', {
            day: 'numeric',
            month: 'long',
            year: 'numeric',
            hour: 'numeric',
            minute: 'numeric'
        }).format(date);
    };

    const calculateBalance = (transactions: Transaction[]): number => {
         return transactions
            .filter(tx => tx.status === 'Completed' || (tx.status === 'Pending' && tx.amount < 0))
            .reduce((acc, tx) => acc + tx.amount, 0);
    };

    // Render Functions
    const renderFarmerInfo = (farmer: FarmerData) => {
        if (!farmerInfoContent) return;
        const setField = (field: string, value: string) => {
            const element = farmerInfoContent.querySelector<HTMLSpanElement>(`[data-field="${field}"]`);
            if (element) element.textContent = value;
        };

        const setStatusField = (field: string, status: VerificationStatus) => {
             const element = farmerInfoContent.querySelector<HTMLSpanElement>(`[data-field="${field}"]`);
             if (element) {
                if (status === 'Verified') {
                    element.textContent = '✓';
                    element.title = 'ভেরিফাইড';
                    element.className = 'verification-status verified';
                } else {
                    element.textContent = '✗';
                    element.title = 'ভেরিফাই করা হয়নি';
                    element.className = 'verification-status not-verified';
                }
             }
        };

        const profilePicElement = document.querySelector('.farmer-profile-pic') as HTMLDivElement;
        if (profilePicElement) {
            profilePicElement.style.backgroundImage = `url(${farmer.profilePic})`;
            if (farmer.profilePic === DEFAULT_PROFILE_PIC) {
                profilePicElement.style.backgroundSize = '60%';
            } else {
                profilePicElement.style.backgroundSize = 'cover';
            }
        }

        setField('name', farmer.name);
        setField('id', farmer.id);

        const machineStatusWrapper = farmerInfoContent.querySelector<HTMLParagraphElement>('[data-field="machine-status-wrapper"]');
        const machineStatusTextElement = farmerInfoContent.querySelector<HTMLSpanElement>('[data-field="machine-status-text"]');

        if (machineStatusWrapper && machineStatusTextElement && reapplyMachineBtn) {
            switch (farmer.machineStatus) {
                case 'Delivered':
                    machineStatusTextElement.textContent = 'ডেলিভারি হইছে';
                    machineStatusTextElement.className = 'machine-status delivered';
                    machineStatusWrapper.style.display = 'flex';
                    reapplyMachineBtn.style.display = 'none';
                    break;
                case 'Not Received':
                    machineStatusTextElement.textContent = 'পাইনি';
                    machineStatusTextElement.className = 'machine-status not-received';
                    machineStatusWrapper.style.display = 'flex';
                    reapplyMachineBtn.style.display = 'inline-block';
                    break;
                default: // Pending
                    machineStatusWrapper.style.display = 'none';
                    break;
            }
        }

        setField('phone', farmer.phone);
        setField('nid-number', farmer.nidNumber);
        setField('address', farmer.address);
        setField('land', farmer.land);
        setField('team-leader', farmer.teamLeader);
        setField('project-manager', farmer.projectManager);

        setStatusField('phone-status', farmer.phoneStatus);
        setStatusField('nid-status', farmer.nidStatus);
    };

    const renderTransactions = (transactions: Transaction[]) => {
        if (!transactionList) return;
        transactionList.innerHTML = ''; // Clear existing list

        transactions.slice(0, 5).forEach(tx => { // Show only the 5 most recent
            const listItem = document.createElement('li');
            listItem.classList.add('transaction-item');

            const isCredit = tx.amount > 0;
            const amountClass = isCredit ? 'credit' : 'debit';
            const sign = isCredit ? '' : '- ';

            listItem.innerHTML = `
                <div class="transaction-details">
                    <span class="transaction-type">${tx.type}</span>
                    <span class="transaction-date">${tx.date}</span>
                </div>
                <span class="amount ${amountClass}">${sign}${formatCurrency(tx.amount)}</span>
            `;
            transactionList.appendChild(listItem);
        });
    };
    
    const renderDetailedTransactions = (transactions: Transaction[], tableBody: HTMLTableSectionElement | null) => {
        if (!tableBody) return;
        tableBody.innerHTML = '';

        let runningBalance = 0;
        const transactionsInChronologicalOrder = [...transactions].reverse();
        
        const transactionsWithBalance = transactionsInChronologicalOrder.map(tx => {
            if (tx.status === 'Completed') { // Only completed transactions affect the running balance
               runningBalance += tx.amount;
            }
            return { ...tx, balance: runningBalance };
        });

        const transactionsToDisplay = transactionsWithBalance.reverse();

        transactionsToDisplay.forEach(tx => {
            const row = document.createElement('tr');
            const isCredit = tx.amount > 0;
            const amountClass = isCredit ? 'credit' : 'debit';
            const sign = isCredit ? '+' : '-';
            const statusClass = tx.status === 'Completed' ? 'status-completed' : 'status-pending';
            const statusText = tx.status === 'Completed' ? 'সম্পন্ন' : 'বিচারাধীন';

            row.innerHTML = `
                <td>${tx.date}</td>
                <td>${tx.type}</td>
                <td class="amount ${amountClass}">${sign} ${formatCurrency(tx.amount)}</td>
                <td>${tx.status === 'Completed' ? formatCurrency(tx.balance) : '-'}</td>
                <td><span class="status-badge ${statusClass}">${statusText}</span></td>
            `;
            tableBody.appendChild(row);
        });
    };

    const renderLoanDetails = (loanTransactions: LoanTransaction[]) => {
        if (!loanSummaryContent || !loanTransactionTableBody) return;
        
        const totalLoan = loanTransactions.filter(tx => tx.description === 'লোন বিতরণ').reduce((sum, tx) => sum + tx.amount, 0);
        const totalPaid = loanTransactions.filter(tx => tx.description !== 'লোন বিতরণ').reduce((sum, tx) => sum + tx.amount, 0);
        const remainingBalance = totalLoan + totalPaid;

        loanSummaryContent.innerHTML = `
            <p><strong>মোট লোন:</strong> ${formatCurrency(totalLoan)}</p>
            <p><strong>মোট পরিশোধিত:</strong> ${formatCurrency(totalPaid)}</p>
            <p><strong>অবশিষ্ট ব্যালেন্স:</strong> ${formatCurrency(remainingBalance)}</p>
            <p><strong>পরবর্তী কিস্তি:</strong> ৳৫,০০০</p>
        `;
        
        loanTransactionTableBody.innerHTML = '';
        loanTransactions.forEach(tx => {
            const row = document.createElement('tr');
            const isCredit = tx.amount > 0;
            const amountClass = isCredit ? 'credit' : 'debit';
            const sign = isCredit ? '+' : '';
            row.innerHTML = `
                <td>${tx.date}</td>
                <td>${tx.description}</td>
                <td class="amount ${amountClass}">${sign} ${formatCurrency(tx.amount)}</td>
                <td>${formatCurrency(tx.balance)}</td>
            `;
            loanTransactionTableBody.appendChild(row);
        });
    };

    const renderComplaintContacts = (farmer: FarmerData) => {
        if (!complaintContactInfo) return;
        complaintContactInfo.innerHTML = `
            <div class="complaint-contact-item">
                <h3>টিম লিডার</h3>
                <p>${farmer.teamLeader} - ${farmer.teamLeaderPhone}</p>
            </div>
            <div class="complaint-contact-item">
                <h3>প্রজেক্ট ম্যানেজার</h3>
                <p>${farmer.projectManager} - ${farmer.projectManagerPhone}</p>
            </div>
        `;
    };

    const updateBalanceDisplay = () => {
        if (!balanceAmountElement) return;
        currentBalance = calculateBalance(loggedInFarmer.transactions);
        balanceAmountElement.textContent = formatCurrency(currentBalance);
    };

    const renderVerificationCard = () => {
        if (!machineVerificationCard || !verificationPendingDiv || !verificationNotReceivedDiv) return;

        if (loggedInFarmer.machineStatus === 'Delivered') {
            machineVerificationCard.style.display = 'none';
        } else if (loggedInFarmer.machineStatus === 'Not Received') {
            machineVerificationCard.style.display = 'block';
            verificationPendingDiv.style.display = 'none';
            verificationNotReceivedDiv.style.display = 'block';
            machineVerificationCard.classList.add('warning-state');

            const setField = (field: string, value: string) => {
                const element = verificationNotReceivedDiv.querySelector<HTMLSpanElement>(`[data-field="${field}"]`);
                if (element) element.textContent = value;
            };
            setField('mv-team-leader', loggedInFarmer.teamLeader);
            setField('mv-team-leader-phone', loggedInFarmer.teamLeaderPhone);
            setField('mv-project-manager', loggedInFarmer.projectManager);
            setField('mv-project-manager-phone', loggedInFarmer.projectManagerPhone);
        } else { // Pending
            machineVerificationCard.style.display = 'block';
            verificationPendingDiv.style.display = 'block';
            verificationNotReceivedDiv.style.display = 'none';
            machineVerificationCard.classList.remove('warning-state');
        }
    };

    const renderFarmerDashboardUI = () => {
        renderFarmerInfo(loggedInFarmer);
        updateBalanceDisplay();
        renderTransactions(loggedInFarmer.transactions);
        renderDetailedTransactions(loggedInFarmer.transactions, detailedTransactionTableBody as HTMLTableSectionElement);
        renderLoanDetails(loggedInFarmer.loanTransactions);
        renderVerificationCard();
        renderFarmerUnreadCount();
    };


    // Event Listeners
    if (withdrawForm && withdrawAmountInput) {
        withdrawForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const amountToWithdraw = parseFloat(withdrawAmountInput.value);
            const selectedMethod = (withdrawForm.querySelector('input[name="withdraw-method"]:checked') as HTMLInputElement)?.value;

            if (!selectedMethod) {
                alert('অনুগ্রহ করে একটি উইথড্র মাধ্যম (ব্যাংক/বিকাশ) নির্বাচন করুন।');
                return;
            }

            if (isNaN(amountToWithdraw) || amountToWithdraw <= 0) {
                alert('অনুগ্রহ করে একটি সঠিক পরিমাণ লিখুন।');
                return;
            }

            if (amountToWithdraw > currentBalance) {
                alert('আপনার অ্যাকাউন্টে পর্যাপ্ত ব্যালেন্স নেই।');
                return;
            }
            
            withdrawalRequest = {
                amount: amountToWithdraw,
                method: selectedMethod
            };
            openWithdrawModal();
        });
    }

    // Modal Logic
    const openWithdrawModal = () => {
        if (!modalOverlay || !modalStep1 || !modalStep2 || !modalStep3 || !modalAccountLabel || !withdrawalRequest) return;
        
        modalStep1.style.display = 'block';
        modalStep2.style.display = 'none';
        modalStep3.style.display = 'none';
        modalAccountNumberInput.value = '';

        modalAccountLabel.textContent = withdrawalRequest.method === 'Bank' ? 'ব্যাংক অ্যাকাউন্ট নম্বর দিন' : 'বিকাশ নম্বর দিন';
        modalAccountNumberInput.placeholder = withdrawalRequest.method === 'Bank' ? 'অ্যাকাউন্ট নম্বর লিখুন' : 'বিকাশ নম্বর লিখুন';

        modalOverlay.classList.add('show-modal');
    };

    const closeWithdrawModal = () => {
        if (!modalOverlay) return;
        modalOverlay.classList.remove('show-modal');
        withdrawalRequest = null;
        if(withdrawForm) withdrawForm.reset();
    };

    if (modalCloseBtn) modalCloseBtn.addEventListener('click', closeWithdrawModal);
    if (modalCancelBtn) modalCancelBtn.addEventListener('click', closeWithdrawModal);
    if (modalSuccessOkBtn) modalSuccessOkBtn.addEventListener('click', closeWithdrawModal);

    if(modalContinueBtn) {
        modalContinueBtn.addEventListener('click', () => {
            if (!modalStep1 || !modalStep2 || !withdrawalRequest) return;
            const accountNumber = modalAccountNumberInput.value.trim();
            if (!accountNumber) {
                alert('অনুগ্রহ করে আপনার নম্বরটি লিখুন।');
                return;
            }
            withdrawalRequest.number = accountNumber;
            
            if (modalConfirmAmount) modalConfirmAmount.textContent = formatCurrency(withdrawalRequest.amount);
            if (modalConfirmMethod) modalConfirmMethod.textContent = withdrawalRequest.method === 'Bank' ? 'ব্যাংক' : 'বিকাশ';
            if (modalConfirmNumber) modalConfirmNumber.textContent = withdrawalRequest.number;

            modalStep1.style.display = 'none';
            modalStep2.style.display = 'block';
        });
    }

    if (modalConfirmBtn) {
        modalConfirmBtn.addEventListener('click', () => {
            if (!modalStep2 || !modalStep3 || !withdrawalRequest) return;

            const newTransaction: Transaction = {
                type: `উত্তোলন (${withdrawalRequest.method})`,
                date: formatDate(new Date()),
                amount: -withdrawalRequest.amount,
                status: 'Pending'
            };
            loggedInFarmer.transactions.unshift(newTransaction);
            renderFarmerDashboardUI();
            
            modalStep2.style.display = 'none';
            modalStep3.style.display = 'block';
        });
    }

    // All Offers Modal Logic
    if (viewAllOffersBtn && allOffersModalOverlay) {
        viewAllOffersBtn.addEventListener('click', () => {
            allOffersModalOverlay.classList.add('show-modal');
        });
    }

    const closeAllOffersModal = () => {
        if (allOffersModalOverlay) {
            allOffersModalOverlay.classList.remove('show-modal');
        }
    };

    if (allOffersModalCloseBtn) {
        allOffersModalCloseBtn.addEventListener('click', closeAllOffersModal);
    }
    
    if (allOffersModalOverlay) {
        allOffersModalOverlay.addEventListener('click', (e) => {
            if (e.target === allOffersModalOverlay) {
                closeAllOffersModal();
            }
        });
    }



    // Page Navigation Logic
    if (toggleDetailsBtn) toggleDetailsBtn.addEventListener('click', () => showPanel('transaction-details-page'));
    if (loanDetailsBtn) loanDetailsBtn.addEventListener('click', () => showPanel('loan-details-page'));
    if (machineReceivedYesBtn) machineReceivedYesBtn.addEventListener('click', () => showPanel('machine-upload-page'));
    if (machineReceivedNoBtn) {
        machineReceivedNoBtn.addEventListener('click', () => {
            renderComplaintContacts(loggedInFarmer);
            showPanel('complaint-page');
        });
    }

    if (editInfoBtn) {
        editInfoBtn.addEventListener('click', () => {
             if (!editInfoForm) return;
            // Populate form with current data before showing the page
            (editInfoForm.elements.namedItem('name') as HTMLInputElement).value = loggedInFarmer.name;
            (editInfoForm.elements.namedItem('phone') as HTMLInputElement).value = loggedInFarmer.phone === 'যোগ করা হয়নি' ? '' : loggedInFarmer.phone;
            (editInfoForm.elements.namedItem('address') as HTMLInputElement).value = loggedInFarmer.address;
            (editInfoForm.elements.namedItem('land') as HTMLInputElement).value = loggedInFarmer.land;
            (editInfoForm.elements.namedItem('nid-number') as HTMLInputElement).value = loggedInFarmer.nidNumber === 'যোগ করা হয়নি' ? '' : loggedInFarmer.nidNumber;
            
            if (profilePicPreview) profilePicPreview.src = loggedInFarmer.profilePic;
            if (fileNameDisplay) fileNameDisplay.textContent = 'কোনো ফাইল বাছাই করা হয়নি';
            if (nidUploadInput) nidUploadInput.value = '';

            showPanel('edit-info-page');
        });
    }

    if (cancelEditPageBtn) cancelEditPageBtn.addEventListener('click', backToDashboard);
    

    // Edit Info Page Logic
    if (profilePicUploadInput && profilePicPreview) {
        profilePicUploadInput.addEventListener('change', () => {
            const file = profilePicUploadInput.files?.[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    profilePicPreview.src = e.target?.result as string;
                };
                reader.readAsDataURL(file);
            }
        });
    }

    if (nidUploadInput && fileNameDisplay) {
        nidUploadInput.addEventListener('change', () => {
            if (nidUploadInput.files && nidUploadInput.files.length > 0) {
                fileNameDisplay.textContent = nidUploadInput.files[0].name;
            } else {
                fileNameDisplay.textContent = 'কোনো ফাইল বাছাই করা হয়নি';
            }
        });
    }
    
    if (verifyPhoneBtn) {
        verifyPhoneBtn.addEventListener('click', () => {
             const phoneNumber = (editInfoForm.elements.namedItem('phone') as HTMLInputElement).value;
             if (phoneNumber) {
                alert('ফোন নম্বর ভেরিফিকেশন সফল হয়েছে!');
                loggedInFarmer.phoneStatus = 'Verified';
             } else {
                alert('অনুগ্রহ করে ফোন নম্বর লিখুন।');
             }
        });
    }

    if (verifyNidBtn) {
        verifyNidBtn.addEventListener('click', () => {
            const nidNumber = (editInfoForm.elements.namedItem('nid-number') as HTMLInputElement).value;
            if (nidUploadInput.files && nidUploadInput.files.length > 0 && nidNumber) {
                alert('NID ভেরিফিকেশন সফল হয়েছে!');
                loggedInFarmer.nidStatus = 'Verified';
                loggedInFarmer.nidNumber = nidNumber;
            } else {
                alert('অনুগ্রহ করে NID নম্বর লিখুন এবং NID কার্ডের ছবি আপলোড করুন।');
            }
        });
    }

    if (editInfoForm) {
        editInfoForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const getFormValue = (name: string, defaultValue: string) => {
                const value = (editInfoForm.elements.namedItem(name) as HTMLInputElement).value;
                return value.trim() === '' ? defaultValue : value;
            };

            if (profilePicPreview && profilePicPreview.src !== loggedInFarmer.profilePic) {
                loggedInFarmer.profilePic = profilePicPreview.src;
            }

            loggedInFarmer.name = getFormValue('name', loggedInFarmer.name);
            loggedInFarmer.phone = getFormValue('phone', 'যোগ করা হয়নি');
            loggedInFarmer.address = getFormValue('address', loggedInFarmer.address);
            loggedInFarmer.land = getFormValue('land', loggedInFarmer.land);
            loggedInFarmer.nidNumber = getFormValue('nid-number', 'যোগ করা হয়নি');
            
            renderFarmerInfo(loggedInFarmer);
            showPanel(lastActiveDashboardId); // Go back to the dashboard
            alert('আপনার তথ্য সফলভাবে সংরক্ষণ করা হয়েছে।');
        });
    }


    // Profile Dropdown Logic
    const closeProfileDropdown = () => {
        if (profileDropdown && profileIcon) {
            profileDropdown.classList.remove('show');
            profileIcon.setAttribute('aria-expanded', 'false');
        }
    };

    if (profileIcon && profileDropdown) {
        profileIcon.addEventListener('click', (event) => {
            event.stopPropagation();
            const isExpanded = profileIcon.getAttribute('aria-expanded') === 'true';
            profileDropdown.classList.toggle('show');
            profileIcon.setAttribute('aria-expanded', String(!isExpanded));
        });

        window.addEventListener('click', () => {
            if (profileDropdown.classList.contains('show')) {
                closeProfileDropdown();
            }
        });

        profileDropdown.addEventListener('click', (event) => {
             event.stopPropagation();
        });
    }

    // Profile Settings Page Logic
    if (profileSettingsLink) {
        profileSettingsLink.addEventListener('click', (e) => {
            e.preventDefault();
            showPanel('profile-settings-page');
            closeProfileDropdown();
        });
    }

    if (changePasswordForm) {
        changePasswordForm.addEventListener('submit', (e) => {
            e.preventDefault();
            alert('পাসওয়ার্ড সফলভাবে আপডেট করা হয়েছে।');
            changePasswordForm.reset();
        });
    }

    if (contactInfoForm) {
        contactInfoForm.addEventListener('submit', (e) => {
            e.preventDefault();
            alert('যোগাযোগের তথ্য সফলভাবে সংরক্ষণ করা হয়েছে।');
        });
    }

    if (notificationPrefsForm) {
        notificationPrefsForm.addEventListener('submit', (e) => {
            e.preventDefault();
            alert('নোটিফিকেশন পছন্দ সফলভাবে সংরক্ষণ করা হয়েছে।');
        });
    }

    if (toggle2faBtn && status2fa) {
        toggle2faBtn.addEventListener('click', () => {
            const isActive = status2fa.classList.contains('active');
            if (isActive) {
                status2fa.classList.remove('active');
                status2fa.classList.add('inactive');
                status2fa.textContent = 'নিষ্ক্রিয়';
                toggle2faBtn.textContent = '2FA সক্রিয় করুন';
                alert('দুই-ফ্যাক্টর অথেনটিকেশন নিষ্ক্রিয় করা হয়েছে।');
            } else {
                status2fa.classList.remove('inactive');
                status2fa.classList.add('active');
                status2fa.textContent = 'সক্রিয়';
                toggle2faBtn.textContent = '2FA নিষ্ক্রিয় করুন';
                alert('দুই-ফ্যাক্টর অথেনটিকেশন সফলভাবে সক্রিয় করা হয়েছে।');
            }
        });
    }

    // Machine Upload Page Logic
    const handleImagePreview = (input: HTMLInputElement, preview: HTMLImageElement) => {
        const file = input.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                preview.src = e.target?.result as string;
                preview.style.display = 'block';
                const label = preview.parentElement as HTMLLabelElement;
                if(label.querySelector('span')) {
                    (label.querySelector('span') as HTMLSpanElement).style.display = 'none';
                }
            };
            reader.readAsDataURL(file);
        }
    };

    if (memoUploadInput && memoPreview) {
        memoUploadInput.addEventListener('change', () => handleImagePreview(memoUploadInput, memoPreview));
    }
    if (machineUploadInput && machinePreview) {
        machineUploadInput.addEventListener('change', () => handleImagePreview(machineUploadInput, machinePreview));
    }

    if (machineUploadForm) {
        machineUploadForm.addEventListener('submit', (e) => {
            e.preventDefault();
            if (!memoUploadInput.files?.length || !machineUploadInput.files?.length) {
                alert('অনুগ্রহ করে দুটি ছবিই আপলোড করুন।');
                return;
            }
            alert('আপনার ছবি সফলভাবে জমা দেওয়া হয়েছে।');
            
            loggedInFarmer.machineStatus = 'Delivered';

            machineUploadForm.reset();
            memoPreview.src = '';
            memoPreview.style.display = 'none';
             const memoLabel = memoPreview.parentElement as HTMLLabelElement;
            if (memoLabel.querySelector('span')) {
                (memoLabel.querySelector('span') as HTMLSpanElement).style.display = 'block';
            }
            machinePreview.src = '';
            machinePreview.style.display = 'none';
            const machineLabel = machinePreview.parentElement as HTMLLabelElement;
            if (machineLabel.querySelector('span')) {
                (machineLabel.querySelector('span') as HTMLSpanElement).style.display = 'block';
            }

            renderFarmerDashboardUI();
            backToDashboard();
        });
    }

    // Complaint Page Logic
    if (makeComplaintBtn) {
        makeComplaintBtn.addEventListener('click', () => {
            const complaintMessageInput = document.getElementById('complaint-message') as HTMLTextAreaElement;
            const message = complaintMessageInput.value.trim();

            if (!message) {
                alert('অনুগ্রহ করে আপনার অভিযোগের বিস্তারিত লিখুন।');
                return;
            }
            
            // Create a new complaint message
            const newComplaint: ComplaintMessage = {
                id: `complaint-${Date.now()}`,
                farmerId: loggedInFarmer.id,
                farmerName: loggedInFarmer.name,
                teamLeaderId: loggedInFarmer.teamLeaderId,
                subject: 'মেশিন না পাওয়া সংক্রান্ত অভিযোগ',
                message: message,
                timestamp: new Date(),
                readStatus: {
                    farmer: true,
                    teamLeader: false,
                    projectManager: false,
                },
                replies: []
            };
            complaintMessages.push(newComplaint);
            renderAllUnreadCounts();

            alert('আপনার অভিযোগ গ্রহণ করা হয়েছে। আমাদের একজন প্রতিনিধি শীঘ্রই আপনার সাথে যোগাযোগ করবে।');
            loggedInFarmer.machineStatus = 'Not Received';

            if (complaintMessageInput) {
                complaintMessageInput.value = '';
            }
            
            renderFarmerDashboardUI();
            backToDashboard();
        });
    }

    if (reapplyMachineBtn) {
        reapplyMachineBtn.addEventListener('click', () => {
            loggedInFarmer.machineStatus = 'Pending';
            renderFarmerDashboardUI();
            
            const machineVerificationCardElement = document.querySelector('.machine-verification');
            if (machineVerificationCardElement) {
                machineVerificationCardElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        });
    }
    
    // Promo Card Logic
    const copyPromoButtons = document.querySelectorAll('.copy-promo-btn');
    copyPromoButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetId = (button as HTMLElement).dataset.clipboardTarget;
            if (!targetId) return;

            const targetElement = document.querySelector(targetId);
            const promoCode = targetElement?.textContent;

            if (promoCode) {
                navigator.clipboard.writeText(promoCode).then(() => {
                    // Success feedback
                    button.classList.add('copied');
                    setTimeout(() => {
                        button.classList.remove('copied');
                    }, 2000); // Remove feedback after 2 seconds
                }).catch(err => {
                    console.error('Failed to copy text: ', err);
                    alert('কোড কপি করতে সমস্যা হয়েছে।');
                });
            }
        });
    });

    // --- Team Leader Dashboard Logic ---
    const renderTeamLeaderInfo = () => {
        const setField = (field: string, value: string) => {
            const element = document.querySelector(`[data-field="${field}"]`);
            if (element) element.textContent = value;
        };

        const profilePicElement = document.getElementById('tl-profile-pic') as HTMLDivElement;
        if (profilePicElement) {
            profilePicElement.style.backgroundImage = `url(${teamLeaderData.profilePic})`;
            if (teamLeaderData.profilePic === DEFAULT_PROFILE_PIC) {
                profilePicElement.style.backgroundSize = '60%';
            } else {
                profilePicElement.style.backgroundSize = 'cover';
            }
        }
        setField('tl-name', teamLeaderData.name);
        setField('tl-id', teamLeaderData.id);
        setField('tl-phone', teamLeaderData.phone);
        setField('tl-project-manager', teamLeaderData.projectManager);
    };

    const renderFarmerStats = () => {
        const totalFarmers = allFarmers.length;
        const loanReceived = allFarmers.filter(f => f.hasLoan).length;
        const loanNotReceived = totalFarmers - loanReceived;

        const setField = (field: string, value: string | number) => {
            const element = document.querySelector(`[data-field="${field}"]`);
            if (element) element.textContent = String(value);
        };
        setField('total-farmers', totalFarmers);
        setField('loan-received', loanReceived);
        setField('loan-not-received', loanNotReceived);
    };

    const renderTotalLoanAmount = () => {
        const totalLoan = allFarmers.reduce((total, farmer) => {
            const loanTx = farmer.transactions.find(tx => tx.type === 'মোট লোন প্রাপ্তি' && tx.status === 'Completed');
            return total + (loanTx ? loanTx.amount : 0);
        }, 0);

        const totalLoanAmountElement = document.getElementById('total-loan-amount');
        if (totalLoanAmountElement) {
            totalLoanAmountElement.textContent = formatCurrency(totalLoan);
        }
    };
    
    const viewFarmerDetails = (farmerId: string) => {
        const farmer = allFarmers.find(f => f.id === farmerId);
        if (!farmer) return;

        // Populate Farmer Info
        const infoContent = document.getElementById('view-farmer-info-content');
        if (infoContent) {
            const statusToHtml = (status: VerificationStatus) => {
                const isVerified = status === 'Verified';
                const icon = isVerified ? '✓' : '✗';
                const className = isVerified ? 'verified' : 'not-verified';
                const title = isVerified ? 'ভেরিফাইড' : 'ভেরিফাই করা হয়নি';
                return `<span class="verification-status ${className}" title="${title}">${icon}</span>`;
            };
            
            infoContent.innerHTML = `
                <div class="farmer-identity-header">
                    <div class="farmer-profile-pic" style="background-image: url(${farmer.profilePic}); background-size: ${farmer.profilePic === DEFAULT_PROFILE_PIC ? '60%' : 'cover'};"></div>
                    <div class="farmer-main-identity">
                        <h3>${farmer.name}</h3>
                        <p>${farmer.id}</p>
                    </div>
                </div>
                <div class="farmer-contact-details">
                    <div class="contact-item">
                        <span class="contact-label">ফোন নম্বর</span>
                        <div class="contact-value-group">
                            <span class="contact-value">${farmer.phone}</span>
                            ${statusToHtml(farmer.phoneStatus)}
                        </div>
                    </div>
                    <div class="contact-item">
                        <span class="contact-label">NID নম্বর</span>
                         <div class="contact-value-group">
                            <span class="contact-value">${farmer.nidNumber}</span>
                             ${statusToHtml(farmer.nidStatus)}
                        </div>
                    </div>
                </div>
                <div class="farmer-other-details">
                    <p><strong>ঠিকানা:</strong> <span>${farmer.address}</span></p>
                    <p><strong>জমির পরিমাণ:</strong> <span>${farmer.land}</span></p>
                </div>`;
        }
        
        // Populate Balance
        const balanceElement = document.getElementById('view-balance-amount');
        if (balanceElement) {
            balanceElement.textContent = formatCurrency(calculateBalance(farmer.transactions));
        }

        // Populate Transactions
        const transactionTableBody = document.querySelector('#view-detailed-transaction-table tbody');
        renderDetailedTransactions(farmer.transactions, transactionTableBody as HTMLTableSectionElement);

        showPanel('farmer-details-from-tl-page');
    };


    const renderFarmerLists = () => {
        const machineList = document.getElementById('machine-not-received-list');
        const balanceList = document.getElementById('farmer-balances-list');

        if (!machineList || !balanceList) return;

        machineList.innerHTML = '';
        balanceList.innerHTML = '';

        const farmersWithoutMachine = allFarmers.filter(f => f.machineStatus === 'Not Received');
        
        if (farmersWithoutMachine.length === 0) {
            machineList.innerHTML = '<li>এই মুহূর্তে কোনো কৃষক নেই।</li>';
        } else {
            farmersWithoutMachine.forEach(farmer => {
                const li = document.createElement('li');
                li.innerHTML = `
                    <button data-farmer-id="${farmer.id}">${farmer.name} (${farmer.id})</button>
                    <svg class="warning-icon" xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" title="এই কৃষক মেশিন পায়নি">
                        <path d="M0 0h24v24H0V0z" fill="none"/>
                        <path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/>
                    </svg>
                `;
                machineList.appendChild(li);
            });
        }
        
        allFarmers.forEach(farmer => {
            const li = document.createElement('li');
            const balance = calculateBalance(farmer.transactions);
            li.innerHTML = `
                <button data-farmer-id="${farmer.id}">${farmer.name} (${farmer.id})</button>
                <span class="balance">${formatCurrency(balance)}</span>
            `;
            balanceList.appendChild(li);
        });

        // Add event listeners to all newly created buttons
        document.querySelectorAll('.farmer-list button').forEach(button => {
            button.addEventListener('click', () => {
                const farmerId = (button as HTMLElement).dataset.farmerId;
                if(farmerId) viewFarmerDetails(farmerId);
            });
        });
    };

    const renderTeamLeaderDashboard = () => {
        renderTeamLeaderInfo();
        renderFarmerStats();
        renderTotalLoanAmount();
        renderFarmerLists();
        renderTlUnreadCount();
    };

    if (editTlInfoBtn) {
        editTlInfoBtn.addEventListener('click', () => {
            if (!editTlInfoForm || !tlProfilePicPreview) return;
            (editTlInfoForm.elements.namedItem('tl-name') as HTMLInputElement).value = teamLeaderData.name;
            (editTlInfoForm.elements.namedItem('tl-phone') as HTMLInputElement).value = teamLeaderData.phone;
            tlProfilePicPreview.src = teamLeaderData.profilePic;
            showPanel('edit-tl-info-page');
        });
    }

    if (tlProfilePicUploadInput && tlProfilePicPreview) {
        tlProfilePicUploadInput.addEventListener('change', () => handleImagePreview(tlProfilePicUploadInput, tlProfilePicPreview));
    }
    
    if (editTlInfoForm) {
        editTlInfoForm.addEventListener('submit', (e) => {
            e.preventDefault();
            if (tlProfilePicPreview) {
                teamLeaderData.profilePic = tlProfilePicPreview.src;
            }
            teamLeaderData.name = (editTlInfoForm.elements.namedItem('tl-name') as HTMLInputElement).value;
            teamLeaderData.phone = (editTlInfoForm.elements.namedItem('tl-phone') as HTMLInputElement).value;
            
            renderTeamLeaderInfo();
            showPanel('team-leader-dashboard');
            alert('আপনার তথ্য সফলভাবে সংরক্ষণ করা হয়েছে।');
        });
    }
    
    if(backToTlDashboardFromEditBtn) backToTlDashboardFromEditBtn.addEventListener('click', () => showPanel('team-leader-dashboard'));
    if(cancelTlEditPageBtn) cancelTlEditPageBtn.addEventListener('click', () => showPanel('team-leader-dashboard'));
    if(backToTlDashboardFromDetailsBtn) backToTlDashboardFromDetailsBtn.addEventListener('click', () => showPanel('team-leader-dashboard'));

    
    // --- Project Manager Dashboard ---
    const renderPmStats = () => {
        const totalLeaders = teamLeaders.length;
        const totalFarmers = allFarmers.length;
        const totalLoan = allFarmers.reduce((total, farmer) => {
            const loanTx = farmer.transactions.find(tx => tx.type === 'মোট লোন প্রাপ্তি' && tx.status === 'Completed');
            return total + (loanTx ? loanTx.amount : 0);
        }, 0);
        const pendingIssues = allFarmers.filter(f => f.machineStatus === 'Not Received').length;

        const setField = (field: string, value: string | number) => {
            const element = document.querySelector(`[data-field="${field}"]`);
            if (element) element.textContent = String(value);
        };
        setField('pm-total-leaders', totalLeaders);
        setField('pm-total-farmers', totalFarmers);
        setField('pm-total-loan', formatCurrency(totalLoan));
        setField('pm-pending-issues', pendingIssues);
    };

    const renderTeamLeaderList = () => {
        const container = document.getElementById('team-leader-list-container');
        if (!container) return;
        container.innerHTML = '';

        teamLeaders.forEach(leader => {
            const farmersInTeam = allFarmers.filter(f => f.teamLeaderId === leader.id);
            const issuesInTeam = farmersInTeam.filter(f => f.machineStatus === 'Not Received').length;
            const totalLoanInTeam = farmersInTeam.reduce((total, farmer) => {
                const loanTx = farmer.transactions.find(tx => tx.type === 'মোট লোন প্রাপ্তি' && tx.status === 'Completed');
                return total + (loanTx ? loanTx.amount : 0);
            }, 0);
            
            const card = document.createElement('div');
            card.className = 'team-leader-card';
            if (issuesInTeam > 0) {
                card.classList.add('has-issues');
            }

            card.innerHTML = `
                <div class="tl-card-info">
                    <h3>${leader.name}</h3>
                    <p>${leader.id}</p>
                </div>
                <div class="tl-card-stats">
                    <div class="stat">
                        <span class="stat-number">${farmersInTeam.length}</span>
                        <span>জন কৃষক</span>
                    </div>
                    <div class="stat">
                        <span class="stat-number">${formatCurrency(totalLoanInTeam)}</span>
                        <span>মোট লোন</span>
                    </div>
                     ${issuesInTeam > 0 ? `
                    <div class="stat issues">
                        <span class="stat-number">${issuesInTeam}</span>
                        <span>টি সমস্যা</span>
                    </div>` : ''}
                </div>
                <div class="tl-card-actions">
                    <button class="details-btn" data-tl-id="${leader.id}">বিস্তারিত দেখুন</button>
                </div>
            `;
            container.appendChild(card);
        });

        container.querySelectorAll('.details-btn').forEach(button => {
            button.addEventListener('click', () => {
                const tlId = (button as HTMLElement).dataset.tlId;
                if (tlId) viewTeamLeaderDetailsFromPm(tlId);
            });
        });
    };

    const viewTeamLeaderDetailsFromPm = (teamLeaderId: string) => {
        currentTlIdForPm = teamLeaderId;
        const leader = teamLeaders.find(tl => tl.id === teamLeaderId);
        if (!leader) return;

        const header = document.getElementById('tl-details-pm-header');
        if (header) header.textContent = `${leader.name} এর বিস্তারিত`;

        const infoContent = document.getElementById('tl-details-pm-info-content');
        if (infoContent) {
            infoContent.innerHTML = `
                <div class="farmer-identity-header">
                    <div class="farmer-profile-pic" style="background-image: url(${leader.profilePic}); background-size: ${leader.profilePic === DEFAULT_PROFILE_PIC ? '60%' : 'cover'};"></div>
                    <div class="farmer-main-identity">
                        <h3>${leader.name}</h3>
                        <p>${leader.id}</p>
                    </div>
                </div>
                <div class="farmer-other-details">
                     <p><strong>ফোন নম্বর:</strong> <span>${leader.phone}</span></p>
                     <p><strong>প্রজেক্ট ম্যানেজার:</strong> <span>${leader.projectManager}</span></p>
                </div>`;
        }
        
        const farmersInTeam = allFarmers.filter(f => f.teamLeaderId === teamLeaderId);
        const machineList = document.getElementById('tl-details-pm-machine-list');
        const balanceList = document.getElementById('tl-details-pm-balance-list');

        if (machineList) {
             machineList.innerHTML = '';
             const farmersWithoutMachine = farmersInTeam.filter(f => f.machineStatus === 'Not Received');
             if(farmersWithoutMachine.length > 0) {
                 farmersWithoutMachine.forEach(farmer => {
                    const li = document.createElement('li');
                    li.innerHTML = `<button data-farmer-id="${farmer.id}">${farmer.name} (${farmer.id})</button> <svg class="warning-icon" xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>`;
                    machineList.appendChild(li);
                });
             } else {
                 machineList.innerHTML = '<li>এই টিমের সব কৃষক মেশিন পেয়েছেন।</li>';
             }
        }
        if(balanceList) {
            balanceList.innerHTML = '';
            farmersInTeam.forEach(farmer => {
                const li = document.createElement('li');
                li.innerHTML = `<button data-farmer-id="${farmer.id}">${farmer.name} (${farmer.id})</button> <span class="balance">${formatCurrency(calculateBalance(farmer.transactions))}</span>`;
                balanceList.appendChild(li);
            });
        }
        
        document.querySelectorAll('#team-leader-details-from-pm-page .farmer-list button').forEach(button => {
            button.addEventListener('click', () => {
                const farmerId = (button as HTMLElement).dataset.farmerId;
                if(farmerId) viewFarmerDetailsFromPm(farmerId);
            });
        });

        showPanel('team-leader-details-from-pm-page');
    };

    const viewFarmerDetailsFromPm = (farmerId: string) => {
        const farmer = allFarmers.find(f => f.id === farmerId);
        if (!farmer) return;

        const infoContent = document.getElementById('view-farmer-info-content-pm');
        if (infoContent) {
            const statusToHtml = (status: VerificationStatus) => {
                const isVerified = status === 'Verified';
                const icon = isVerified ? '✓' : '✗';
                const className = isVerified ? 'verified' : 'not-verified';
                const title = isVerified ? 'ভেরিফাইড' : 'ভেরিফাই করা হয়নি';
                return `<span class="verification-status ${className}" title="${title}">${icon}</span>`;
            };
            
            infoContent.innerHTML = `<div class="farmer-identity-header"><div class="farmer-profile-pic" style="background-image: url(${farmer.profilePic}); background-size: ${farmer.profilePic === DEFAULT_PROFILE_PIC ? '60%' : 'cover'};"></div><div class="farmer-main-identity"><h3>${farmer.name}</h3><p>${farmer.id}</p></div></div><div class="farmer-contact-details"><div class="contact-item"><span class="contact-label">ফোন নম্বর</span><div class="contact-value-group"><span class="contact-value">${farmer.phone}</span>${statusToHtml(farmer.phoneStatus)}</div></div><div class="contact-item"><span class="contact-label">NID নম্বর</span><div class="contact-value-group"><span class="contact-value">${farmer.nidNumber}</span>${statusToHtml(farmer.nidStatus)}</div></div></div><div class="farmer-other-details"><p><strong>ঠিকানা:</strong> <span>${farmer.address}</span></p><p><strong>জমির পরিমাণ:</strong> <span>${farmer.land}</span></p></div>`;
        }
        
        const balanceElement = document.getElementById('view-balance-amount-pm');
        if (balanceElement) {
            balanceElement.textContent = formatCurrency(calculateBalance(farmer.transactions));
        }

        const transactionTableBody = document.querySelector('#view-detailed-transaction-table-pm tbody');
        renderDetailedTransactions(farmer.transactions, transactionTableBody as HTMLTableSectionElement);

        showPanel('farmer-details-from-pm-page');
    };


    const renderProjectManagerDashboard = () => {
        renderPmStats();
        renderTeamLeaderList();
        renderPmUnreadCount();
    };

    if(backToPmDashboardFromTlDetailsBtn) backToPmDashboardFromTlDetailsBtn.addEventListener('click', () => showPanel('project-manager-dashboard'));
    if(backToTlDetailsFromFarmerViewBtn) {
        backToTlDetailsFromFarmerViewBtn.addEventListener('click', () => {
            if(currentTlIdForPm) viewTeamLeaderDetailsFromPm(currentTlIdForPm);
        });
    }

    // --- Inbox Logic (All Dashboards) ---

    const renderAllUnreadCounts = () => {
        renderFarmerUnreadCount();
        renderTlUnreadCount();
        renderPmUnreadCount();
    }

    // --- Farmer Inbox Logic ---
    const renderFarmerUnreadCount = () => {
        const unreadCount = complaintMessages.filter(m => m.farmerId === loggedInFarmer.id && !m.readStatus.farmer).length;
        const notificationBadge = document.getElementById('farmer-inbox-notification');
        if (notificationBadge) {
            if (unreadCount > 0) {
                notificationBadge.textContent = String(unreadCount);
                notificationBadge.style.display = 'flex';
            } else {
                notificationBadge.style.display = 'none';
            }
        }
    };
    
    const renderFarmerInbox = () => {
        const inboxList = document.getElementById('farmer-inbox-list');
        if (!inboxList) return;
        const messages = complaintMessages.filter(m => m.farmerId === loggedInFarmer.id);

        inboxList.innerHTML = '';
        if (messages.length === 0) {
            inboxList.innerHTML = '<li class="inbox-empty">আপনার কোনো বার্তা নেই।</li>';
            return;
        }

        const sortedMessages = [...messages].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

        sortedMessages.forEach(msg => {
            const li = document.createElement('li');
            li.className = 'message-item';
            if (!msg.readStatus.farmer) {
                li.classList.add('unread');
            }
            li.dataset.messageId = msg.id;
            
            const lastReply = msg.replies[msg.replies.length - 1];
            const sender = lastReply ? lastReply.from : 'আপনি';

            li.innerHTML = `
                <div class="message-sender">${sender}</div>
                <div class="message-subject">${msg.subject}</div>
                <div class="message-snippet">${msg.message.substring(0, 50)}...</div>
                <div class="message-date">${formatDateTime(msg.timestamp)}</div>
            `;

            li.addEventListener('click', () => {
                viewFarmerMessageDetail(msg.id);
            });
            inboxList.appendChild(li);
        });
    };

    const viewFarmerMessageDetail = (messageId: string) => {
        currentViewingMessageId = messageId;
        const message = complaintMessages.find(m => m.id === messageId);
        if (!message) return;

        message.readStatus.farmer = true;
        renderAllUnreadCounts();

        const subjectHeader = document.getElementById('farmer-inbox-detail-subject');
        const messageBodyP = document.getElementById('farmer-inbox-message-body');
        const conversationHistoryDiv = document.getElementById('farmer-inbox-conversation-history');

        if (subjectHeader) subjectHeader.textContent = message.subject;
        if (messageBodyP) messageBodyP.textContent = message.message;
        
        if (conversationHistoryDiv) {
            conversationHistoryDiv.innerHTML = ''; // Clear previous
            // Add original message to history view
            const originalMessageDiv = document.createElement('div');
            originalMessageDiv.className = 'conversation-item';
            originalMessageDiv.innerHTML = `<div class="conversation-header"><strong>আপনি</strong><span>${formatDateTime(message.timestamp)}</span></div><p>${message.message}</p>`;
            conversationHistoryDiv.appendChild(originalMessageDiv);

            message.replies.forEach(reply => {
                const replyDiv = document.createElement('div');
                replyDiv.className = 'conversation-item';
                replyDiv.innerHTML = `
                    <div class="conversation-header">
                        <strong>${reply.from}</strong>
                        <span>${formatDateTime(reply.timestamp)}</span>
                    </div>
                    <p>${reply.message}</p>
                `;
                conversationHistoryDiv.appendChild(replyDiv);
            });
        }
        
        if(farmerInboxReplyForm) farmerInboxReplyForm.reset();
        showPanel('farmer-inbox-detail-page');
    };

    if (farmerInboxBtn) {
        farmerInboxBtn.addEventListener('click', () => {
            renderFarmerInbox();
            showPanel('farmer-inbox-page');
        });
    }
    if (backToFarmerDashboardFromInboxBtn) backToFarmerDashboardFromInboxBtn.addEventListener('click', () => showPanel('farmer-dashboard'));
    if (backToFarmerInboxFromDetailBtn) {
        backToFarmerInboxFromDetailBtn.addEventListener('click', () => {
            renderFarmerInbox();
            showPanel('farmer-inbox-page');
        });
    }
    if (farmerInboxReplyForm) {
        farmerInboxReplyForm.addEventListener('submit', e => {
            e.preventDefault();
            const replyTextarea = document.getElementById('farmer-reply-message') as HTMLTextAreaElement;
            const replyMessage = replyTextarea.value.trim();

            if (!replyMessage || !currentViewingMessageId) return;

            const message = complaintMessages.find(m => m.id === currentViewingMessageId);
            if (message) {
                message.replies.push({
                    from: 'Farmer',
                    message: replyMessage,
                    timestamp: new Date()
                });
                message.readStatus.teamLeader = false;
                message.readStatus.projectManager = false;
                renderAllUnreadCounts();
                alert('আপনার উত্তর সফলভাবে পাঠানো হয়েছে।');
                viewFarmerMessageDetail(currentViewingMessageId);
            }
        });
    }

    // --- Team Leader Inbox Logic ---
    const renderTlUnreadCount = () => {
        const unreadCount = complaintMessages.filter(m => m.teamLeaderId === teamLeaderData.id && !m.readStatus.teamLeader).length;
        const notificationBadge = document.getElementById('tl-inbox-notification');
        if (notificationBadge) {
            if (unreadCount > 0) {
                notificationBadge.textContent = String(unreadCount);
                notificationBadge.style.display = 'flex';
            } else {
                notificationBadge.style.display = 'none';
            }
        }
    };

    const renderTlInbox = () => {
        const inboxList = document.getElementById('tl-inbox-list');
        if (!inboxList) return;
        const messages = complaintMessages.filter(m => m.teamLeaderId === teamLeaderData.id);

        inboxList.innerHTML = '';
        if (messages.length === 0) {
            inboxList.innerHTML = '<li class="inbox-empty">কোনো নতুন অভিযোগ নেই।</li>';
            return;
        }
        
        const sortedMessages = [...messages].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

        sortedMessages.forEach(msg => {
            const li = document.createElement('li');
            li.className = 'message-item';
            if (!msg.readStatus.teamLeader) li.classList.add('unread');
            li.dataset.messageId = msg.id;
            
            li.innerHTML = `
                <div class="message-sender">${msg.farmerName}</div>
                <div class="message-subject">${msg.subject}</div>
                <div class="message-snippet">${msg.message.substring(0, 50)}...</div>
                <div class="message-date">${formatDateTime(msg.timestamp)}</div>
            `;
            li.addEventListener('click', () => viewTlMessageDetail(msg.id));
            inboxList.appendChild(li);
        });
    };

    const viewTlMessageDetail = (messageId: string) => {
        currentViewingMessageId = messageId;
        const message = complaintMessages.find(m => m.id === messageId);
        const farmer = allFarmers.find(f => f.id === message?.farmerId);
        if (!message || !farmer) return;

        message.readStatus.teamLeader = true;
        renderAllUnreadCounts();

        const subjectHeader = document.getElementById('tl-inbox-detail-subject');
        const farmerInfoDiv = document.getElementById('tl-inbox-farmer-info');
        const messageBodyP = document.getElementById('tl-inbox-message-body');
        const conversationHistoryDiv = document.getElementById('tl-inbox-conversation-history');

        if (subjectHeader) subjectHeader.textContent = message.subject;
        if (farmerInfoDiv) farmerInfoDiv.innerHTML = `<p><strong>নাম:</strong> ${farmer.name}</p><p><strong>আইডি:</strong> ${farmer.id}</p><p><strong>ফোন:</strong> ${farmer.phone}</p>`;
        if (messageBodyP) messageBodyP.textContent = message.message;
        
        if (conversationHistoryDiv) {
            conversationHistoryDiv.innerHTML = '';
             const originalMessageDiv = document.createElement('div');
            originalMessageDiv.className = 'conversation-item';
            originalMessageDiv.innerHTML = `<div class="conversation-header"><strong>${message.farmerName}</strong><span>${formatDateTime(message.timestamp)}</span></div><p>${message.message}</p>`;
            conversationHistoryDiv.appendChild(originalMessageDiv);
            message.replies.forEach(reply => {
                const replyDiv = document.createElement('div');
                replyDiv.className = 'conversation-item';
                replyDiv.innerHTML = `<div class="conversation-header"><strong>${reply.from}</strong><span>${formatDateTime(reply.timestamp)}</span></div><p>${reply.message}</p>`;
                conversationHistoryDiv.appendChild(replyDiv);
            });
        }
        
        if(tlInboxReplyForm) tlInboxReplyForm.reset();
        showPanel('tl-inbox-detail-page');
    };

    if (tlInboxBtn) {
        tlInboxBtn.addEventListener('click', () => {
            renderTlInbox();
            showPanel('tl-inbox-page');
        });
    }
    if (backToTlDashboardFromInboxBtn) backToTlDashboardFromInboxBtn.addEventListener('click', () => showPanel('team-leader-dashboard'));
    if (backToTlInboxFromDetailBtn) {
        backToTlInboxFromDetailBtn.addEventListener('click', () => {
            renderTlInbox();
            showPanel('tl-inbox-page');
        });
    }
    if (tlInboxReplyForm) {
        tlInboxReplyForm.addEventListener('submit', e => {
            e.preventDefault();
            const replyTextarea = document.getElementById('tl-reply-message') as HTMLTextAreaElement;
            const replyMessage = replyTextarea.value.trim();

            if (!replyMessage || !currentViewingMessageId) return;

            const message = complaintMessages.find(m => m.id === currentViewingMessageId);
            if (message) {
                message.replies.push({
                    from: 'Team Leader',
                    message: replyMessage,
                    timestamp: new Date()
                });
                message.readStatus.farmer = false;
                message.readStatus.projectManager = false;
                renderAllUnreadCounts();
                alert('আপনার উত্তর সফলভাবে পাঠানো হয়েছে।');
                viewTlMessageDetail(currentViewingMessageId);
            }
        });
    }

    // --- PM Inbox Logic ---
    const renderPmUnreadCount = () => {
        const unreadCount = complaintMessages.filter(m => !m.readStatus.projectManager).length;
        const notificationBadge = document.getElementById('pm-inbox-notification');
        if (notificationBadge) {
            if (unreadCount > 0) {
                notificationBadge.textContent = String(unreadCount);
                notificationBadge.style.display = 'flex';
            } else {
                notificationBadge.style.display = 'none';
            }
        }
    };

    const renderPmInbox = () => {
        const inboxList = document.getElementById('pm-inbox-list');
        if (!inboxList) return;

        inboxList.innerHTML = '';
        if (complaintMessages.length === 0) {
            inboxList.innerHTML = '<li class="inbox-empty">কোনো নতুন অভিযোগ নেই।</li>';
            return;
        }

        const sortedMessages = [...complaintMessages].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

        sortedMessages.forEach(msg => {
            const li = document.createElement('li');
            li.className = 'message-item';
            if (!msg.readStatus.projectManager) {
                li.classList.add('unread');
            }
            li.dataset.messageId = msg.id;
            
            li.innerHTML = `
                <div class="message-sender">${msg.farmerName}</div>
                <div class="message-subject">${msg.subject}</div>
                <div class="message-snippet">${msg.message.substring(0, 50)}...</div>
                <div class="message-date">${formatDateTime(msg.timestamp)}</div>
            `;

            li.addEventListener('click', () => {
                viewPmMessageDetail(msg.id);
            });
            inboxList.appendChild(li);
        });
    };
    
    const viewPmMessageDetail = (messageId: string) => {
        currentViewingMessageId = messageId;
        const message = complaintMessages.find(m => m.id === messageId);
        const farmer = allFarmers.find(f => f.id === message?.farmerId);
        if (!message || !farmer) return;

        message.readStatus.projectManager = true;
        renderAllUnreadCounts();

        const subjectHeader = document.getElementById('pm-inbox-detail-subject');
        const farmerInfoDiv = document.getElementById('pm-inbox-farmer-info');
        const messageBodyP = document.getElementById('pm-inbox-message-body');
        const conversationHistoryDiv = document.getElementById('pm-inbox-conversation-history');

        if (subjectHeader) subjectHeader.textContent = message.subject;
        if (farmerInfoDiv) {
            farmerInfoDiv.innerHTML = `
                <p><strong>নাম:</strong> ${farmer.name}</p>
                <p><strong>আইডি:</strong> ${farmer.id}</p>
                <p><strong>ফোন:</strong> ${farmer.phone}</p>
                <p><strong>টিম লিডার:</strong> ${farmer.teamLeader}</p>
            `;
        }
        if (messageBodyP) messageBodyP.textContent = message.message;
        
        if (conversationHistoryDiv) {
            conversationHistoryDiv.innerHTML = ''; // Clear previous
            const originalMessageDiv = document.createElement('div');
            originalMessageDiv.className = 'conversation-item';
            originalMessageDiv.innerHTML = `<div class="conversation-header"><strong>${message.farmerName}</strong><span>${formatDateTime(message.timestamp)}</span></div><p>${message.message}</p>`;
            conversationHistoryDiv.appendChild(originalMessageDiv);
            message.replies.forEach(reply => {
                const replyDiv = document.createElement('div');
                replyDiv.className = 'conversation-item';
                replyDiv.innerHTML = `
                    <div class="conversation-header">
                        <strong>${reply.from}</strong>
                        <span>${formatDateTime(reply.timestamp)}</span>
                    </div>
                    <p>${reply.message}</p>
                `;
                conversationHistoryDiv.appendChild(replyDiv);
            });
        }
        
        if(pmInboxReplyForm) pmInboxReplyForm.reset();
        showPanel('pm-inbox-detail-page');
    };
    
    if (pmInboxBtn) {
        pmInboxBtn.addEventListener('click', () => {
            renderPmInbox();
            showPanel('pm-inbox-page');
        });
    }

    if(backToPmDashboardFromInboxBtn) backToPmDashboardFromInboxBtn.addEventListener('click', () => showPanel('project-manager-dashboard'));
    if(backToInboxFromDetailBtn) {
        backToInboxFromDetailBtn.addEventListener('click', () => {
            renderPmInbox();
            showPanel('pm-inbox-page');
        });
    }

    if (pmInboxReplyForm) {
        pmInboxReplyForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const replyTextarea = document.getElementById('pm-reply-message') as HTMLTextAreaElement;
            const replyMessage = replyTextarea.value.trim();

            if (!replyMessage || !currentViewingMessageId) return;

            const message = complaintMessages.find(m => m.id === currentViewingMessageId);
            if (message) {
                message.replies.push({
                    from: 'Project Manager',
                    message: replyMessage,
                    timestamp: new Date()
                });
                message.readStatus.farmer = false;
                message.readStatus.teamLeader = false;
                renderAllUnreadCounts();
                alert('আপনার উত্তর সফলভাবে পাঠানো হয়েছে।');
                viewPmMessageDetail(currentViewingMessageId); // Re-render the detail view with the new reply
            }
        });
    }


    // Initial App Load
    renderFarmerDashboardUI();
    renderAllUnreadCounts();
});